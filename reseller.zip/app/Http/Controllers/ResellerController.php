<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Reseller;

class ResellerController extends Controller
{
    public function index()
    {
        $reseller = Reseller::paginate(10);
        return view ('admin.resellers.index', compact('reseller'));
    }

    public function create()
    {
        return view ('admin.resellers.create');
    }

    public function store(Request $request)
    {
        $reseller = Reseller::create([
            'name' => $request->name
        ]);
        alert()->success('Success','Data Berhasil Di Simpan !');
        return redirect()->back();
    }

    public function show($id)
    {
        $reseller = Reseller::find($id);
        return view ('admin.resellers.detail', compact('reseller'));
    }
    
    public function edit($id)
    {
        $reseller = Reseller::find($id);
           return view ('admin.resellers.edit', compact('reseller'));
    }

    // public function update(Request $request, $id)
    // {
    //     $this->validate($request, [
    //         'name' => 'required'
    //     ]);

    //     $category_data = [
    //         'name' => $request->name
    //     ];

    //     Category::whereId($id)->update($category_data);
    //     alert()->success('Success','Data Berhasil Di Update !');
    //     return redirect()->back();
    // }

    public function destroy($id)
    {   
        $reseller = Reseller::find($id);
        $reseller->delete();
        return redirect()->back()->with('success', 'Data Reseller berhasil di Hapus');
    }
}
