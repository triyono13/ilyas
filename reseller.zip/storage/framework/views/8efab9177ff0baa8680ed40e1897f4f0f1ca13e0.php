        <!-- JAVASCRIPT -->
        <script src="<?php echo e(URL::asset('libs/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('libs/bootstrap/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('libs/metismenu/metismenu.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('libs/simplebar/simplebar.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('libs/node-waves/node-waves.min.js')); ?>"></script>

        <?php echo $__env->yieldContent('script'); ?>

        <!-- App js -->
        <script src="<?php echo e(URL::asset('js/app.min.js')); ?>"></script>

        <?php echo $__env->yieldContent('script-bottom'); ?><?php /**PATH C:\xampp\htdocs\reseller\resources\views/layouts/footer-script.blade.php ENDPATH**/ ?>