

<?php $__env->startSection('title'); ?> Dashboard <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('common-components.breadcrumb'); ?>
         <?php $__env->slot('title'); ?> Admin   <?php $__env->endSlot(); ?>
         <?php $__env->slot('title_li'); ?> Dashboard   <?php $__env->endSlot(); ?>
     <?php if (isset($__componentOriginalca1ecd71c079b0986f63b19e32f1541d590c0929)): ?>
<?php $component = $__componentOriginalca1ecd71c079b0986f63b19e32f1541d590c0929; ?>
<?php unset($__componentOriginalca1ecd71c079b0986f63b19e32f1541d590c0929); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<div class="row">
    <div class="col-xl-12">

        <div class="row">
            <div class="col-xl-3 col-lg-6 col-12 col-sm-6 mb-12">

     <?php $__env->startComponent('common-components.dashboard2-widget'); ?>
         <?php $__env->slot('title'); ?> Pemasukkan Hari Ini  <?php $__env->endSlot(); ?>
         <?php $__env->slot('total'); ?> Rp. <?php echo e(number_format($hari_ini,0,',','.')); ?>,- <?php $__env->endSlot(); ?>
         <?php $__env->slot('tanggal'); ?> <?php echo e($hari); ?> <?php $__env->endSlot(); ?>
     <?php if (isset($__componentOriginal677c313774522416a33db59b0e31d03dad38f571)): ?>
<?php $component = $__componentOriginal677c313774522416a33db59b0e31d03dad38f571; ?>
<?php unset($__componentOriginal677c313774522416a33db59b0e31d03dad38f571); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
            </div>
            <div class="col-xl-3 col-lg-6 col-12 col-sm-6 mb-12">

     <?php $__env->startComponent('common-components.dashboard2-widget'); ?>
         <?php $__env->slot('title'); ?> Pemasukkan Bulan Ini  <?php $__env->endSlot(); ?>
         <?php $__env->slot('total'); ?> Rp. <?php echo e(number_format($bulan_ini,0,',','.')); ?>,- <?php $__env->endSlot(); ?>
         <?php $__env->slot('tanggal'); ?> <?php echo e($bulan); ?> <?php $__env->endSlot(); ?>
     <?php if (isset($__componentOriginal677c313774522416a33db59b0e31d03dad38f571)): ?>
<?php $component = $__componentOriginal677c313774522416a33db59b0e31d03dad38f571; ?>
<?php unset($__componentOriginal677c313774522416a33db59b0e31d03dad38f571); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

            </div>
            <div class="col-xl-3 col-lg-6 col-12 col-sm-6 mb-12">

    <?php $__env->startComponent('common-components.dashboard2-widget'); ?>
        <?php $__env->slot('title'); ?> Pemasukkan Tahun Ini  <?php $__env->endSlot(); ?>
        <?php $__env->slot('total'); ?> Rp. <?php echo e(number_format($tahun_ini,0,',','.')); ?>,- <?php $__env->endSlot(); ?>
        <?php $__env->slot('tanggal'); ?> <?php echo e($tahun); ?> <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginal677c313774522416a33db59b0e31d03dad38f571)): ?>
<?php $component = $__componentOriginal677c313774522416a33db59b0e31d03dad38f571; ?>
<?php unset($__componentOriginal677c313774522416a33db59b0e31d03dad38f571); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

            </div>
            <div class="col-xl-3 col-lg-6 col-12 col-sm-6 mb-12">

    <?php $__env->startComponent('common-components.dashboard2-widget'); ?>
        <?php $__env->slot('title'); ?> Total Pemasukkan  <?php $__env->endSlot(); ?>
        <?php $__env->slot('total'); ?> Rp. <?php echo e(number_format($semua_pemasukkan,0,',','.')); ?>,- <?php $__env->endSlot(); ?>
        <?php $__env->slot('tanggal'); ?> Semua <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginal677c313774522416a33db59b0e31d03dad38f571)): ?>
<?php $component = $__componentOriginal677c313774522416a33db59b0e31d03dad38f571; ?>
<?php unset($__componentOriginal677c313774522416a33db59b0e31d03dad38f571); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xl-12">

        <div class="row">
            <div class="col-xl-3 col-lg-6 col-12 col-sm-6 mb-12">

     <?php $__env->startComponent('common-components.dashboard2-widget'); ?>
         <?php $__env->slot('title'); ?> Total Transaksi  <?php $__env->endSlot(); ?>
         <?php $__env->slot('total'); ?> 0 <?php $__env->endSlot(); ?>
         <?php $__env->slot('tanggal'); ?> <?php echo e($hari); ?> <?php $__env->endSlot(); ?>
     <?php if (isset($__componentOriginal677c313774522416a33db59b0e31d03dad38f571)): ?>
<?php $component = $__componentOriginal677c313774522416a33db59b0e31d03dad38f571; ?>
<?php unset($__componentOriginal677c313774522416a33db59b0e31d03dad38f571); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
            </div>
            <div class="col-xl-3 col-lg-6 col-12 col-sm-6 mb-12">

     <?php $__env->startComponent('common-components.dashboard2-widget'); ?>
         <?php $__env->slot('title'); ?> Total Reseller  <?php $__env->endSlot(); ?>
         <?php $__env->slot('total'); ?> 1 <?php $__env->endSlot(); ?>
         <?php $__env->slot('tanggal'); ?> <?php echo e($bulan); ?> <?php $__env->endSlot(); ?>
     <?php if (isset($__componentOriginal677c313774522416a33db59b0e31d03dad38f571)): ?>
<?php $component = $__componentOriginal677c313774522416a33db59b0e31d03dad38f571; ?>
<?php unset($__componentOriginal677c313774522416a33db59b0e31d03dad38f571); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

            </div>
            <div class="col-xl-3 col-lg-6 col-12 col-sm-6 mb-12">

    <?php $__env->startComponent('common-components.dashboard2-widget'); ?>
        <?php $__env->slot('title'); ?> Total Barang  <?php $__env->endSlot(); ?>
        <?php $__env->slot('total'); ?> 11 <?php $__env->endSlot(); ?>
        <?php $__env->slot('tanggal'); ?> <?php echo e($tahun); ?> <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginal677c313774522416a33db59b0e31d03dad38f571)): ?>
<?php $component = $__componentOriginal677c313774522416a33db59b0e31d03dad38f571; ?>
<?php unset($__componentOriginal677c313774522416a33db59b0e31d03dad38f571); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

            </div>
            <div class="col-xl-3 col-lg-6 col-12 col-sm-6 mb-12">

    <?php $__env->startComponent('common-components.dashboard2-widget'); ?>
        <?php $__env->slot('title'); ?> Best Seller Barang  <?php $__env->endSlot(); ?>
        <?php $__env->slot('total'); ?> Skin Care XXX <?php $__env->endSlot(); ?>
        <?php $__env->slot('tanggal'); ?> Semua <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginal677c313774522416a33db59b0e31d03dad38f571)): ?>
<?php $component = $__componentOriginal677c313774522416a33db59b0e31d03dad38f571; ?>
<?php unset($__componentOriginal677c313774522416a33db59b0e31d03dad38f571); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
            </div>
        </div>
    </div>
</div>



<!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- apexcharts -->


<script src="<?php echo e(URL::asset('/js/pages/apexcharts.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\reseller\resources\views/admin/index.blade.php ENDPATH**/ ?>