

<?php $__env->startSection('title'); ?> Users <?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(URL::asset('/libs/datatables/datatables.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('libs/bootstrap-datepicker/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('common-components.breadcrumb'); ?>
         <?php $__env->slot('title'); ?> Admin   <?php $__env->endSlot(); ?>
         <?php $__env->slot('title_li'); ?> Users  <?php $__env->endSlot(); ?>
     <?php if (isset($__componentOriginalca1ecd71c079b0986f63b19e32f1541d590c0929)): ?>
<?php $component = $__componentOriginalca1ecd71c079b0986f63b19e32f1541d590c0929; ?>
<?php unset($__componentOriginalca1ecd71c079b0986f63b19e32f1541d590c0929); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
     <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <a href="<?php echo e(route('reseller.create')); ?>" class="btn btn-success waves-effect waves-light" role="button" aria-pressed="true">Tambah Reseller</a><hr>
                    <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                            <tr>
                                <th style="width:1%; text-align: center;">No.</th>
                                <th style="width:5%; text-align: center;">Nama</th>
                                <th style="width:5%; text-align: center;">Total Transaksi</th>
                                <th style="width:5%; text-align: center;">Tempat/TGL Lahir</th>
                                <th style="width:30%; text-align: center;">Alamat Lengkap</th>
                                <th style="width:5%; text-align: center;">No.Telp</th>
                                <th style="width:5%; text-align: center;">Nama Agen</th>
                                <th style="width:5%; text-align: center;">Wilayah</th>
                                <th style="text-align: center;">Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                            <?php $__currentLoopData = $reseller; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result => $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($result + $reseller -> firstitem()); ?></td>
                                <td><?php echo e($hasil->nama); ?></td>
                                <td>11</td>
                                <td><?php echo e($hasil->tempat_lahir); ?> <br> <?php echo e($hasil->tgl_lahir); ?></td>
                                <td><textarea name="" id="" cols="43" rows="2" disabled><?php echo e($hasil->alamat); ?>&#13;&#10;RT:004/RW:002  &#13;&#10;Provinsi : <?php echo e($hasil->provinsi); ?> &#13;&#10;Kota/Kab : <?php echo e($hasil->kota); ?> &#13;&#10;Kelurahan : <?php echo e($hasil->kelurahan); ?></textarea></td>
                                <td><?php echo e($hasil->telp); ?></td>
                                <td><?php echo e($hasil->nama_agen); ?></td>
                                <td><?php echo e($hasil->wilayah); ?></td>
                                <td>
                                    <form action="<?php echo e(route('reseller.destroy', $hasil->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <a href="<?php echo e(route('reseller.show', $hasil->id)); ?>" data-toggle="popover" data-placement="top" data-trigger="hover" data-content="Detail Reseller" class="btn btn-primary btn-flat btn-sm">
                                        <span class="dripicons dripicons-document"></span> Detail</a>
                                        <button type="submit" class="btn btn-danger btn-sm btn-flat" data-toggle="popover" data-trigger="hover" data-placement="top" data-content="Hapus Transaksi" onclick="return confirm('Yakin ingin menghapus data Transaksi ?')"><span class="dripicons dripicons-trash"> Hapus</span></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
        <!-- end col -->
    </div>
    <!-- end row -->
    
<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="<?php echo e(asset('libs/bootstrap-datepicker/bootstrap-datepicker.min.js')); ?>"></script>
<!-- Required datatable js -->
<script src="<?php echo e(URL::asset('/libs/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('/libs/jszip/jszip.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('/libs/pdfmake/pdfmake.min.js')); ?>"></script>

<!-- Datatable init js -->
<script src="<?php echo e(URL::asset('/js/pages/datatables.init.js')); ?>"></script> 
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\reseller\resources\views/admin/resellers/index.blade.php ENDPATH**/ ?>