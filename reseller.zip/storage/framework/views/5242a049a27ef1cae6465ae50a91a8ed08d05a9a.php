<div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-8">
                                <div>
                                    <p class="text-muted font-weight-medium mt-1 mb-2"><?php echo e($title); ?></p>
                                    <h4><?php echo e($total); ?></h4>
                                </div>
                            </div>

                            <div class="col-4">
                                <div>
                                    <div id=""></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                   <?php /**PATH C:\xampp\htdocs\reseller\resources\views/common-components/dashboard2-widget.blade.php ENDPATH**/ ?>